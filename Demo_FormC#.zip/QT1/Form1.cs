﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QT1
{
    public partial class Form1 : Form
    {
        SqlConnection cn;
        SqlDataAdapter data;
        SqlCommand cm;//action query
        DataTable tb;
        int dk = 0;
        public Form1()
        {
            InitializeComponent();
        }
        public void showGRD(string s)
        {
            data = new SqlDataAdapter(s, cn);
            tb = new DataTable();
            data.Fill(tb);
            grd.DataSource = tb;
        }
        public void enableGRP(bool b, GroupBox groupBox)
        {
            groupBox.Enabled = b;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string s = "initial catalog = QT1_CNPM; data source = DESKTOP-52OPVCH; integrated security = true";
            cn = new SqlConnection(s);
            cn.Open();
            enableGRP(false, grb_Func);
        }

        private void txt_ID_TextChanged(object sender, EventArgs e)
        {
            enableGRP(true, grb_Func);
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            string s = "Select * from Ticket where ID_Ticket = '"+ txt_ID.Text+"'";
            showGRD(s);
        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            txt_ID.Text = string.Empty;
            btn_Search_Click(sender, e);
        }
    }
}
